# Solar SCADA World — Complete Technical Documentation
**Project:** Interactive 3D Smart Solar-Powered Irrigation System  
**Location:** Omdurman, Sudan  
**Engine:** React Three Fiber ^9.6.1 · Three.js ^0.184 · TypeScript 5.9 · Vite  
**Author:** Replit AI — compiled May 2026

---

## Table of Contents

1. [Project Philosophy and Scope](#1-project-philosophy-and-scope)
2. [What Was Built — Complete Feature Breakdown](#2-what-was-built--complete-feature-breakdown)
3. [Code Architecture and File Structure](#3-code-architecture-and-file-structure)
4. [First-Person Controller Implementation](#4-first-person-controller-implementation)
5. [Weapon Mechanics — Detailed Implementation](#5-weapon-mechanics--detailed-implementation)
6. [Zombie Spawner — Key 5](#6-zombie-spawner--key-5)
7. [Dynamic Weather Scenarios — Keys 1 · 2 · 3](#7-dynamic-weather-scenarios--keys-1--2--3)
8. [Keybind Reference and UI Toggle System](#8-keybind-reference-and-ui-toggle-system)
9. [Performance Engineering for Integrated Graphics](#9-performance-engineering-for-integrated-graphics)
10. [Procedural Audio Engine](#10-procedural-audio-engine)
11. [Environmental Systems — Wheat, Forest, Mountains, Rain](#11-environmental-systems--wheat-forest-mountains-rain)
12. [Simulation Data Importer — CSV · JSON · OBJ](#12-simulation-data-importer--csv--json--obj)
13. [AI-to-AI Handoff Guide](#13-ai-to-ai-handoff-guide)
14. [Engineering Constraints — Non-Negotiable Laws](#14-engineering-constraints--non-negotiable-laws)
15. [Extending the System — Exact Instructions for Future AI](#15-extending-the-system--exact-instructions-for-future-ai)

---

## 1. Project Philosophy and Scope

This is a **dual-purpose application**. The outer shell is an immersive first-person 3D educational environment that teaches a visitor exactly how a real 12.98 kW solar-powered drip irrigation system works in a semi-arid Sudanese agricultural setting. The inner engine is a live SCADA (Supervisory Control and Data Acquisition) display that ingests real 72-hour MATLAB/Simulink simulation data and maps it directly onto animated physical objects in the scene — the pump spins faster, the water tank level rises, the battery SoC badge updates, all driven by numbers from real engineering simulations.

The two layers coexist without compromise. The educational visitor clicks on a solar panel and sees real irradiance and power numbers. The engineering user imports a CSV from MATLAB and watches the centrifugal pump RPM respond in real time at 1× to 300× playback speed.

**Guiding constraints never to be violated:**
- No `THREE.PCFSoftShadowMap` with `size > 512` on a `DirectionalLight` (GPU budget)
- No real-time global illumination — baked env maps only
- All textures generated at runtime via Canvas 2D API — no external image files
- The Solar Zenith Angle is a **physical gate** in the control logic, not a neural network input
- The water tank and soil moisture together form a **dual-reservoir multi-modal storage** — never collapse this to a single storage variable

---

## 2. What Was Built — Complete Feature Breakdown

### 2.1 Solar Farm Infrastructure

| Component | File | Description |
|---|---|---|
| PV Array | `SolarArray.tsx` | 22 monocrystalline panels, 2 strings × 11, total 12.98 kW peak. Each panel is a precisely scaled mesh (1.65 m × 1.0 m) with tempered-glass shader (slight blue-tinted specular). Array tilted 20° south-facing. |
| MPPT Controller | `ControlCabinet.tsx` | Clickable cabinet box with live readouts: Voc, Isc, MPPT voltage, efficiency %. |
| MPC Supervisory Cabinet | `ControlCabinet.tsx` | Model Predictive Controller cabinet — shows setpoint, prediction horizon, current error. |
| FOPID Execution Cabinet | `ControlCabinet.tsx` | Fractional-Order PID cabinet — shows Kp/Ki/Kd/λ/μ, actual vs. target flow error. |
| VFD Cabinet | `PumpSystem.tsx` | Variable Frequency Drive — drives pump motor speed, shows Hz and RPM. |
| Centrifugal Pump | `PumpSystem.tsx` | Physical pump body, motor housing, impeller animation (rotation speed = `pumpRpm / 60` rad/s). |
| Water Tank | `WaterTank.tsx` | 6 m cylindrical steel tank. Water level mesh `scaleY` animated toward `waterLevelTarget` each frame via `lerp(current, target, 0.012)`. |
| Battery Bank | `BatteryBank.tsx` | Enclosure with SoC badge. Color shifts green→yellow→red as SoC drops. |
| Weather Station | `WeatherStation.tsx` | Rotating sky camera, pyranometer (upward-facing dome), ambient temperature/RH sensors, anemometer (spinning cups), AI computing node with LSTM label. |
| Hydraulic Piping | `HydraulicPiping.tsx` | PVC pipe network from pump to field, animated flow particles when pump is active. |
| Electrical Wiring | `ElectricalWiring.tsx` | Cable runs from panels → MPPT → battery → VFD → pump, colored by DC/AC convention. |

### 2.2 Terrain and Environment

| System | File | Key Details |
|---|---|---|
| Ground Terrain | `Terrain.tsx` | `heightAt(x,z)` deterministic noise function. Flat within 40 m radius (farm), hills beyond 62 m, mountains beyond 88 m. |
| Desert Floor | `terrain.ts → makeDesertTexture()` | 1024×1024 canvas: sandy beige with 22,000 grain particles, erosion dune lines, rock pebble clusters. |
| Wheat Field | `WheatField.tsx` | 150,000 GPU-instanced blades. SSS fragment shader injection. Traveling wave wind propagation. Dynamic soil wetness. Drip irrigation lines + emitters. |
| Forest Ring | `Forest.tsx` | 900 trees + 350 acacias. 9-layer canopy billboard texture (40 leaf dabs/layer). Wind-sway vertex shader via `onBeforeCompile`. Three cross-planes per billboard = 3 draw calls for full 3D illusion. |
| Mountains | `Mountains.tsx` | 48 major spires, geological strata texture (layered sediment, tectonic cracks), snow caps, shoulder sub-peaks, scree bases. 28 rolling hills. 60 dodecahedral boulders. 32 atmospheric horizon ridges with blue-shift haze. |
| Rock Formations | `RockFormations.tsx` | Mid-field boulder clusters, instanced dodecahedra. |
| Sky | `RealisticSky.tsx` | Gradient hemisphere with sun position driven by `weather.sunColor`. Dynamic top/middle sky colors per weather mode. |
| Sun Lens Flare | `SunLensFlare.tsx` | Stacked transparent discs on sun billboard. Visibility occlusion via raycasting. |
| Cloud Layer | `CloudLayer.tsx` | 24 cloud groups drifting on XZ plane, animated via `useFrame`. Opacity driven by weather mode. |

### 2.3 First-Person Immersion

The player inhabits the world at eye height (1.72 m). There are no loading screens, no orbit controls, no menu barriers after the start screen is dismissed. The world loads completely under a `<Suspense>` with `fallback={null}`.

### 2.4 Combat System

Three weapons with physically distinct behavior. Zombie hordes up to 50 units with GPU-instanced body parts. Muzzle flash point light. Explosion radii. All audio synthesized procedurally.

### 2.5 Weather and Rain

Three named scenarios control 11 physical parameters simultaneously. Rain toggle (key 6) adds 6,000 GPU-instanced raindrops, 120 splash rings, ripple domes, a wet-ground reflection plane, synchronized audio.

### 2.6 Simulation Data Engine

A diegetic panel (visible in the world) allows drag-and-drop or file-picker import of CSV, JSON, or OBJ data. Once loaded, the simulation clock ticks at 1× to 300× speed and the `simStep` object overrides all weather context values every frame. The 3D world directly visualizes the imported data.

---

## 3. Code Architecture and File Structure

```
artifacts/3d-game/
├── src/
│   ├── main.tsx                        Entry point. Mounts <App />.
│   ├── App.tsx                         Root component. Owns ALL React state for the
│   │                                   game session. Provides Canvas + two providers.
│   ├── context/
│   │   ├── WeatherContext.tsx          Global state hub: weather mode, rain toggle,
│   │   │                               selected object, simStep, simActive.
│   │   └── ImportContext.tsx           Holds the imported OBJ geometry buffer.
│   ├── components/
│   │   ├── Scene.tsx                   R3F scene assembler. Composes all 3D components.
│   │   │                               Passes isLocked and callback props down.
│   │   ├── FirstPersonController.tsx   WASD + mouse-look. No pointer-lock API.
│   │   │                               Fires callbacks: onLockChange, onWeatherKey,
│   │   │                               onRainToggle, onWeaponToggle, onHUDToggle,
│   │   │                               onCombatUIToggle, onAllUIToggle.
│   │   ├── Lighting.tsx                One DirectionalLight (sun, shadow 512px map).
│   │   │                               One AmbientLight. No other light sources except
│   │   │                               the muzzle flash PointLight in CombatSystem.
│   │   ├── Terrain.tsx                 Ground mesh. Uses heightAt() for vertex positions.
│   │   ├── WheatField.tsx              150k GPU blades. SSS shader. Wave wind. Wetness.
│   │   ├── Forest.tsx                  900+350 instanced tree billboards. Wind shader.
│   │   ├── Mountains.tsx               48 spires + hills + boulders + horizon ridges.
│   │   ├── RockFormations.tsx          Near-field boulders.
│   │   ├── RainSystem.tsx              6000 drops + splash + wet plane. Calls
│   │   │                               tickAmbience() in useFrame for audio.
│   │   ├── RealisticSky.tsx            Gradient hemisphere + sun billboard.
│   │   ├── SunLensFlare.tsx            Stacked flare discs, occlusion-tested.
│   │   ├── CloudLayer.tsx              24 drifting cloud groups.
│   │   ├── SolarArray.tsx              22-panel PV array, tilt animation, glass shader.
│   │   ├── ControlCabinet.tsx          MPPT / MPC / FOPID cabinets. Clickable.
│   │   ├── PumpSystem.tsx              Pump + motor + VFD. Impeller rotation.
│   │   ├── WaterTank.tsx               6m tank. Water level lerp animation.
│   │   ├── BatteryBank.tsx             Battery enclosure + SoC badge.
│   │   ├── WeatherStation.tsx          Sensors, anemometer, rotating sky camera.
│   │   ├── IrrigationField.tsx         Field rows + soil moisture color bands.
│   │   ├── IrrigationWater.tsx         Animated flow particles in drip lines.
│   │   ├── HydraulicPiping.tsx         PVC pipe network, flow particles.
│   │   ├── ElectricalWiring.tsx        Cable runs, colored by DC/AC.
│   │   ├── CombatSystem.tsx            Zombie AI, bullets, explosions, weapon models,
│   │   │                               muzzle flash. Calls audioEngine on every shot.
│   │   ├── SimulationDataPanel.tsx     Diegetic import panel. CSV/JSON parser.
│   │   │                               Playback clock. Sparkline charts.
│   │   ├── OBJViewer.tsx               Renders imported OBJ geometry in world.
│   │   ├── HUD.tsx                     Fixed DOM overlay: health, zombie count,
│   │   │                               irradiance, power, flow, SoC, weather badge.
│   │   ├── Crosshair.tsx               Dot + weapon label. Hidden by key 0.
│   │   ├── WeatherSelector.tsx         Weather scenario panel (shown/hidden by key 4).
│   │   ├── StartScreen.tsx             Pre-game keybind reference card.
│   │   ├── InfoOverlay.tsx             Device inspection panel (shown on key E).
│   │   └── WebGLErrorBoundary.tsx      Catches WebGL context loss gracefully.
│   └── utils/
│       ├── terrain.ts                  heightAt(), sampleHeight(), makeDesertTexture(),
│       │                               makeRockTexture(), makeTreeTexture(),
│       │                               makeAcaciaTexture(), makeTreeBarkTex()
│       └── audioEngine.ts              Web Audio API singleton. Procedural synthesis.
│                                       Exports: playPistol, playMachineGun, playBazooka,
│                                       playShellCasing, playEmptyClick, playWeaponSwitch,
│                                       playReload, setRainIntensity, playThunder,
│                                       tickAmbience.
├── index.html
├── vite.config.ts                      BASE_PATH from env. PORT from env.
├── tsconfig.json
└── package.json                        @workspace/3d-game
```

### 3.1 Data Flow Diagram

```
App.tsx (React state)
  ├─ WeatherProvider (Context)
  │    ├─ weather: WeatherData        ← mode profile OR simStep override
  │    ├─ isRaining: boolean
  │    ├─ simStep: SimStep | null     ← live imported data row
  │    └─ selected: SelectedObject    ← clicked device
  │
  ├─ Canvas (R3F)
  │    ├─ Scene.tsx
  │    │    ├─ Lighting              reads weather.sunIntensity, sunColor
  │    │    ├─ RealisticSky          reads weather.skyTop, skyMiddle
  │    │    ├─ WheatField            reads isRaining (soil wetness)
  │    │    ├─ RainSystem            reads isRaining → tickAmbience() audio
  │    │    ├─ WaterTank             reads weather.waterLevelTarget → lerp
  │    │    ├─ PumpSystem            reads weather.pumpRpm → impeller speed
  │    │    └─ CombatSystem          fires audioEngine on weapon events
  │    │
  │    └─ FirstPersonController      fires callbacks → App state setters
  │
  └─ GameUI (DOM overlay)
       ├─ HUD                        reads weather.* for live metrics
       ├─ Crosshair                  visible={showCombatUI}
       └─ SimulationDataPanel        writes simStep → WeatherContext
```

---

## 4. First-Person Controller Implementation

**File:** `src/components/FirstPersonController.tsx`

### 4.1 Why No Pointer Lock API

The `document.pointerLockElement` API is unreliable across browser security contexts, especially in iframe-embedded deployments (Replit preview). Instead, the controller uses a **synthetic lock** model:

1. User clicks the canvas → `requestLockRef.current()` is called
2. The controller enters "locked" mode (an internal boolean ref) and shows the cursor as `none` via CSS
3. Mouse movement events are read from `document.addEventListener("mousemove", ...)` without requiring OS-level pointer capture
4. Escape key sets locked = false and restores the cursor

This means the controller works identically in all environments: Replit preview, deployed production, local dev.

### 4.2 Movement Implementation

```typescript
// Velocity is accumulated per-frame from key state, then integrated
const keys = useRef({ w: false, a: false, s: false, d: false,
                      shift: false, space: false });

useFrame((state, delta) => {
  const cam = state.camera;
  
  // Extract flat (XZ) forward direction from camera yaw
  const forward = new THREE.Vector3();
  cam.getWorldDirection(forward);
  forward.y = 0; forward.normalize();
  
  const right = forward.clone().cross(THREE.Object3D.DEFAULT_UP);

  // Accumulate movement
  const move = new THREE.Vector3();
  if (keys.current.w) move.addScaledVector(forward,  speed * delta);
  if (keys.current.s) move.addScaledVector(forward, -speed * delta);
  if (keys.current.a) move.addScaledVector(right,   -speed * delta);
  if (keys.current.d) move.addScaledVector(right,    speed * delta);

  // Terrain-follow: clamp Y to heightAt(x,z) + eyeHeight
  cam.position.add(move);
  const groundY = heightAt(cam.position.x, cam.position.z);
  cam.position.y = Math.max(cam.position.y, groundY + EYE_HEIGHT);
});
```

**Sprint:** `Shift` multiplies speed by 2.2  
**Jump:** `Space` adds +4.0 to vertical velocity, gravity decelerates at −18 m/s² per frame  
**Look:** Mouse delta rotates camera Euler Y (yaw) and X (pitch), pitch clamped to ±88°

### 4.3 Key Dispatch

All non-movement keys fire callbacks to App.tsx state setters via props. The controller never holds weather/UI state itself — it is a pure input dispatcher:

```typescript
const onKey = (e: KeyboardEvent) => {
  if (e.code === "Digit1") onWeatherKey("1");
  if (e.code === "Digit2") onWeatherKey("2");
  if (e.code === "Digit3") onWeatherKey("3");
  if (e.code === "Digit4") onWeatherToggle();
  if (e.code === "Digit6") onRainToggle();
  if (e.code === "KeyV")   onWeaponToggle();
  if (e.code === "KeyH")   onHUDToggle();
  if (e.code === "Digit0") onCombatUIToggle();
  if (e.code === "Digit9") onAllUIToggle();
  // Keys 5 / Tab / R / scroll-wheel are handled inside CombatSystem
  // because they need direct access to weapon state refs
};
```

### 4.4 Interact Zone Detection (Key E)

Each inspectable device registers itself in a global interaction map (or uses proximity detection). When the camera is within 4.5 m of a device center and the player presses E, `onInteractZone(label)` fires, which sets `selected` in WeatherContext, causing `InfoOverlay` to render the device data panel.

---

## 5. Weapon Mechanics — Detailed Implementation

**File:** `src/components/CombatSystem.tsx`

### 5.1 Weapon Configuration Table

```typescript
const WEAPON_CFG = {
  pistol:     { dmg: 60,  cd: 0.55, recoilZ: 0.07, recoilY: 0.03,  muzzle: "#FFE040" },
  machinegun: { dmg: 18,  cd: 0.09, recoilZ: 0.03, recoilY: 0.012, muzzle: "#FFAA22" },
  bazooka:    { dmg: 200, cd: 2.2,  recoilZ: 0.12, recoilY: 0.06,  muzzle: "#FF6600" },
};
```

- `cd` = cooldown in seconds (min time between shots)
- `recoilZ` = weapon kicks backward by this much along local Z
- `recoilY` = weapon rises by this much on Y axis
- `muzzle` = color of the muzzle flash point light

### 5.2 Weapon Positioning — Camera-Space Attachment

The `weaponGroupRef` (a `<group>`) is manually parented to camera space each frame via `useFrame`:

```typescript
useFrame(({ camera }, delta) => {
  const wg = weaponGroupRef.current;
  if (!wg) return;

  // Determine hip-fire vs. ADS offset
  const targetOffset = isADS.current ? ADS_OFFSET : HIP_OFFSET;
  
  // Smooth lerp to target offset (ADS transition)
  wg.position.lerp(
    camera.position.clone().add(
      targetOffset.clone().applyQuaternion(camera.quaternion)
    ),
    0.22
  );
  wg.quaternion.slerp(camera.quaternion, 0.22);

  // Apply recoil kick
  recoilZ.current = THREE.MathUtils.lerp(recoilZ.current, 0, delta * 12);
  recoilY.current = THREE.MathUtils.lerp(recoilY.current, 0, delta * 10);
  wg.position.addScaledVector(camera.getWorldDirection(new THREE.Vector3()), recoilZ.current);
  wg.position.y += recoilY.current;

  // Weapon bob from movement
  const moved = camera.position.distanceTo(prevCamPos.current);
  if (moved > 0.005) bobAccum.current += delta * 8;
  weaponBobY.current = Math.sin(bobAccum.current) * 0.018;
  weaponBobX.current = Math.sin(bobAccum.current * 0.5) * 0.009;
  wg.position.y += weaponBobY.current;
  wg.position.x += weaponBobX.current;
  prevCamPos.current.copy(camera.position);
});
```

**Critical:** All weapon meshes use `depthTest={false}` and `renderOrder={999}` to prevent z-fighting with world geometry, since the weapon lives in the same depth buffer as the scene but is rendered in camera local space.

### 5.3 Hitscan vs. Projectile

**Pistol and Machine Gun — hitscan:**
```typescript
function hitscan(dmg: number) {
  const origin = camera.position.clone();
  const dir    = new THREE.Vector3();
  camera.getWorldDirection(dir);
  
  // Cast against zombie bounding spheres (no physics engine needed)
  for (const z of zombies.current) {
    if (z.state !== "alive" && z.state !== "hit") continue;
    const zPos = new THREE.Vector3(z.x, 1.2, z.z);
    const toZ  = zPos.clone().sub(origin);
    const proj  = toZ.dot(dir); // projection along ray
    if (proj < 0 || proj > WEAPON_CFG[weapon.current].maxRange) continue;
    const perp  = toZ.clone().sub(dir.clone().multiplyScalar(proj));
    if (perp.length() < 0.55) { // hit radius
      z.health -= dmg;
      z.state   = z.health <= 0 ? "dying" : "hit";
      z.stateTimer = 0;
      break; // one bullet, one zombie (pistol/MG)
    }
  }
}
```

**Bazooka — kinematic projectile:**
```typescript
// On fire:
bullets.current.push({
  id: _uid++,
  pos: camera.position.clone().addScaledVector(dir, 0.9),
  dir: dir.clone(),
  traveled: 0,
  maxRange: 120,
});

// In useFrame:
for (const b of bullets.current) {
  b.pos.addScaledVector(b.dir, 28 * delta); // 28 m/s
  b.traveled += 28 * delta;
  
  // Check zombie proximity (AOE explosion)
  for (const z of zombies.current) {
    const dist = b.pos.distanceTo(new THREE.Vector3(z.x, 1.2, z.z));
    if (dist < EXPLOSION_R) {
      z.health -= WEAPON_CFG.bazooka.dmg * (1 - dist / EXPLOSION_R);
      if (z.health <= 0) { z.state = "dying"; }
    }
  }
}
```

### 5.4 Weapon Model Architecture — Photorealistic PBR

Each weapon is a `<group>` composed of 8–14 individual `<mesh>` children, each with a dedicated `<meshStandardMaterial>`. Textures are procedurally generated via Canvas 2D:

| Texture | Function | Canvas technique |
|---|---|---|
| `makeGunmetalTex()` | Dark brushed steel | 80 directional grain lines + 18 random scratch marks + edge highlight gradient |
| `makeGripTex()` | Rubber diamond-checkered grip | Repeating arc pattern on dark base + horizontal ridge strokes |
| `makeTubeTex()` | OD-green military tube | Olive drab gradient + 3,000 noise particles + wear scratches |

**Pistol parts (14 meshes):** frame, slide, slide serrations ×3, barrel, muzzle crown, ejection port, front sight, rear sight, trigger guard, trigger, grip, grip backstrap, magazine base plate, picatinny rail.

**M4 Carbine parts (16 meshes):** lower receiver, upper receiver, charging handle, handguard, top rail, M-LOK slots ×5, barrel, flash hider ×2, gas block, front sight post, rear BUIS, magazine body, magazine follower, pistol grip, buffer tube, stock body, butt pad, trigger guard, trigger, foregrip.

**RPG-7 parts (16 meshes):** main launch tube, front bell, rear blast cone, blast shield rings ×3, shoulder rest ×2, trigger housing, pistol grip, trigger, optical sight body, sight lens (blue glass), iron sight bracket ×2, warhead body, warhead cone.

### 5.5 Audio on Every Weapon Event

```typescript
// In tryShoot():
if (weapon.current === "pistol") {
  playPistol();
  setTimeout(() => playShellCasing(), 80 + Math.random() * 60);
} else if (weapon.current === "machinegun") {
  playMachineGun();
  setTimeout(() => playShellCasing(), 55 + Math.random() * 40);
} else {
  playBazooka();
}

// On weapon cycle:
playWeaponSwitch();

// On R key:
playReload(weapon.current); // staged mechanical sequence
```

---

## 6. Zombie Spawner — Key 5

**File:** `src/components/CombatSystem.tsx`

### 6.1 Spawn Logic

Key `Digit5` calls `spawnZombie()`. A maximum of 50 zombies (`MAX_ZOMBIES`) can be alive at once. New zombies spawn at a random angle 18–28 m from the camera position to ensure they are always visible on entry.

```typescript
function spawnZombie() {
  const alive = zombies.current.filter(z => z.state !== "dead").length;
  if (alive >= MAX_ZOMBIES) return; // hard cap

  const angle  = Math.random() * Math.PI * 2;
  const radius = 18 + Math.random() * 10;
  const x = camera.position.x + Math.cos(angle) * radius;
  const z = camera.position.z + Math.sin(angle) * radius;

  zombies.current.push({
    id:          _uid++,
    x, z,
    health:      100, maxHealth: 100,
    state:       "alive",
    stateTimer:  0,
    deathAngle:  Math.random() * Math.PI * 2,
    facingAngle: Math.atan2(camera.position.z - z, camera.position.x - x),
  });
  onZombieCount(zombies.current.filter(z => z.state !== "dead").length);
}
```

### 6.2 Zombie State Machine

Each zombie runs a four-state machine per frame:

```
alive → (range > ATTACK_RANGE) → approach camera (ZOMBIE_SPEED = 1.7 m/s)
alive → (range ≤ ATTACK_RANGE) → attack (damages player 8 hp/s, play lunge)
hit   → (stateTimer < 0.18)    → flash red on body material
hit   → (stateTimer ≥ 0.18)    → return to alive if health > 0
dying → (stateTimer < 1.2)     → collapse (rotate body on deathAngle axis)
dying → (stateTimer ≥ 1.2)     → state = "dead", hide via scale(0)
```

### 6.3 GPU Instancing

All zombies share **6 InstancedMesh** objects: body, head, legL, legR, armL, armR. A single `useFrame` call loops through all 50 zombie slots and updates `instanceMatrix` and `instanceColor` per slot. Dead zombies are placed at `(0, -500, 0)` with `scale(0,0,0)`.

Arm swing animation uses a simple sinusoidal limb rotation:
```typescript
const walkPhase = elapsed * 3.2 + z.id * 1.4;
const armSwing  = Math.sin(walkPhase) * 0.6 * (approaching ? 1 : 0);
// Arm L/R matrices offset by ±0.28 from body center, rotated by armSwing
```

No physics engine is used. No skeleton. No rig. Just matrix math per frame.

---

## 7. Dynamic Weather Scenarios — Keys 1 · 2 · 3

**File:** `src/context/WeatherContext.tsx`

### 7.1 Three Profiles

Weather mode is stored as a `WeatherMode` string (`"clear" | "fluctuating" | "overcast"`) in `WeatherProvider` state. Pressing key 1, 2, or 3 calls `setWeatherMode()`, which swaps the profile immediately.

```typescript
export const WEATHER_PROFILES: Record<WeatherMode, WeatherData> = {
  clear: {
    irradiance: 950, power: 11973, flowRate: 14.06,
    ambientIntensity: 0.55, sunIntensity: 2.2, sunColor: "#FFF5E0",
    skyTop: "#4A90D9", skyMiddle: "#87CEEB",
    avgSoc: 87, waterLevelTarget: 5.03,
  },
  fluctuating: {
    irradiance: 550, power: 4746, flowRate: 13.2,
    ambientIntensity: 0.35, sunIntensity: 1.1, sunColor: "#FFE4B0",
    skyTop: "#7BADD4", skyMiddle: "#B0C8DF",
    avgSoc: 62, waterLevelTarget: 4.6,
  },
  overcast: {
    irradiance: 280, power: 3296, flowRate: 12.39,
    ambientIntensity: 0.55, sunIntensity: 0.4, sunColor: "#C8D8E8",
    skyTop: "#9AAEC0", skyMiddle: "#C8D8E0",
    avgSoc: 40, waterLevelTarget: 4.1,
  },
};
```

### 7.2 What Changes on Mode Switch

Every consuming component reads from `useWeather().weather` — a single reactive object:

| Component | Property consumed | What happens |
|---|---|---|
| `Lighting.tsx` | `sunIntensity`, `sunColor`, `ambientIntensity` | Sun brightness, color temperature, fill light |
| `RealisticSky.tsx` | `skyTop`, `skyMiddle` | Sky gradient colors |
| `CloudLayer.tsx` | `mode` | Cloud opacity (clear=0.15, fluctuating=0.55, overcast=0.82) |
| `WaterTank.tsx` | `waterLevelTarget` | Tank fill height lerp target |
| `PumpSystem.tsx` | `flowRate`, `pumpRpm` | Impeller rotation speed |
| `HUD.tsx` | `irradiance`, `power`, `flowRate`, `avgSoc` | All displayed numbers update |
| `WheatField.tsx` | `mode` (via isRaining) | Wind intensity changes |
| `SolarArray.tsx` | `power` | Panel efficiency badge |

### 7.3 Simulation Override

When `simActive === true`, the `WeatherData` object is **replaced** (not blended) with values derived from the current `SimStep`:

```typescript
const weather: WeatherData = simActive && simStep
  ? {
      ...baseWeather,              // start from mode profile
      irradiance:       simStep.irr,
      power:            simStep.pv,
      flowRate:         Math.round(simStep.flow * 100) / 100,
      avgSoc:           simStep.soc,
      waterLevelTarget: simStep.tank_level,
      pumpRpm:          simStep.pump_rpm,
      // Re-derive lighting from irradiance
      ambientIntensity: 0.15 + (simStep.irr / 950) * 0.45,
      sunIntensity:     0.2  + (simStep.irr / 950) * 2.1,
      sunColor:         simStep.irr > 600 ? "#FFF5E0" : "#FFE4B0",
    }
  : baseWeather;
```

This means imported MATLAB data literally becomes the physics of the scene.

---

## 8. Keybind Reference and UI Toggle System

### 8.1 Complete Keybind Table

| Key | Where handled | Action |
|---|---|---|
| **W A S D** | `FirstPersonController` | Move forward/left/back/right |
| **Shift** | `FirstPersonController` | Sprint (2.2× speed) |
| **Space** | `FirstPersonController` | Jump (+4 m/s vertical) |
| **Mouse move** | `FirstPersonController` | Camera yaw/pitch |
| **Mouse left** | `CombatSystem` | Shoot / auto-fire |
| **Mouse right** | `CombatSystem` | ADS (aim down sights offset) |
| **Scroll wheel** | `CombatSystem` | Cycle weapon (±1) |
| **Tab** | `CombatSystem` | Cycle weapon (+1) |
| **R** | `CombatSystem` | Reload (plays mechanical audio sequence) |
| **E** | `FirstPersonController` | Inspect device (opens InfoOverlay) |
| **Esc** | `FirstPersonController` | Pause / release synthetic lock |
| **1** | `FirstPersonController → App` | Weather: Clear Sky |
| **2** | `FirstPersonController → App` | Weather: Fluctuating |
| **3** | `FirstPersonController → App` | Weather: Overcast |
| **4** | `FirstPersonController → App` | Toggle weather panel visibility |
| **5** | `CombatSystem` | Spawn zombie |
| **6** | `FirstPersonController → App` | Toggle rain |
| **V** | `FirstPersonController → App` | Toggle weapon model visibility |
| **H** | `FirstPersonController → App` | Toggle HUD (metrics overlay) |
| **0** | `FirstPersonController → App` | Toggle combat UI (crosshair + weapon label + 3D weapon) |
| **9** | `FirstPersonController → App` | Cinematic mode — hides ALL UI except a tiny hint |

### 8.2 The Three UI Layers

The UI system has three independent boolean states in `App.tsx`:

```typescript
const [showHUD,      setShowHUD]      = useState(true); // key H
const [showCombatUI, setShowCombatUI] = useState(true); // key 0
const [showAllUI,    setShowAllUI]    = useState(true); // key 9
```

**`showAllUI` (key 9)** is the master override. When false, everything except a `[9] restore UI` hint disappears. It renders before all other UI checks:

```typescript
if (!showAllUI) return <div>[9] restore UI</div>;
```

**`showCombatUI` (key 0)** hides the crosshair AND simultaneously hides the 3D weapon model:
```typescript
const handleCombatUIToggle = useCallback(() => {
  setShowCombatUI(v => !v);
  setShowWeapon(v => !v); // synced
}, []);
```

**`showHUD` (key H)** hides the HUD metrics bar but leaves the crosshair visible. When HUD is hidden, a small `H — show HUD` hint appears bottom-right.

---

## 9. Performance Engineering for Integrated Graphics

This section documents every deliberate optimization made to ensure the game runs at ≥30 FPS on Intel Iris Xe and AMD Vega integrated graphics.

### 9.1 Shadow Budget

Only one shadow-casting light is used:
```typescript
// Lighting.tsx
<directionalLight
  castShadow
  shadow-mapSize={[512, 512]}   // NOT 1024 or 2048
  shadow-camera-near={0.5}
  shadow-camera-far={120}
  shadow-camera-left={-55}
  shadow-camera-right={55}
  shadow-camera-top={55}
  shadow-camera-bottom={-55}
/>
```

Shadow map is 512×512. The frustum is tightly fitted to the farm area. No other light in the scene casts shadows.

### 9.2 No Real-Time Global Illumination

Three.js has no real-time GI. The system uses:
- `AmbientLight` for uniform fill (approximates sky diffuse GI)
- `envMapIntensity` on materials to approximate reflective GI from sky
- **No** `PMREMGenerator`, no `.envMap` from HDR, no `RoomEnvironment`
- The "GI" effect on wet wheat soil is simulated by increasing `metalness` and decreasing `roughness` — a purely material-parameter trick

### 9.3 GPU Instancing — Every Repeated Object

| Object type | Count | Technique |
|---|---|---|
| Wheat blades | 150,000 | `InstancedMesh` with shared `PlaneGeometry` |
| Tree billboards | 900 × 3 planes | 3 `InstancedMesh` objects (0°, 60°, 120° planes) |
| Acacia billboards | 350 × 3 planes | Same pattern as trees |
| Zombies (body) | up to 50 | `InstancedMesh` |
| Zombies (head/limbs) | up to 50 × 5 parts | 5 `InstancedMesh` objects |
| Rain drops | 6,000 | `InstancedMesh` |
| Splash rings | 120 | `InstancedMesh` |
| Bullets | 10 | `InstancedMesh` |
| Explosions | 5 | `InstancedMesh` |

This collapses what would be ~157,000+ draw calls into fewer than 35.

### 9.4 Baked Procedural Textures — No External Files

Every texture in the project is generated once at startup via the Canvas 2D API and cached:

```typescript
const soilTex = useMemo(() => makeSoilTex(), []);
// makeSoilTex() creates a 1024×1024 canvas, paints it, wraps it as CanvasTexture
// This runs once. The GPU texture is cached in Three's memory until the component unmounts.
```

**No HTTP requests. No image loading latency. No CDN dependency.** The full environment loads from a single JavaScript bundle.

### 9.5 Shader Injection via `onBeforeCompile`

Custom effects (SSS, wind sway) are injected into MeshStandardMaterial's existing GLSL at specific string anchors rather than writing full custom shaders. This preserves Three.js's optimized PBR math while adding only the delta:

```typescript
mat.onBeforeCompile = (shader) => {
  // Inject uniform declarations at top of vertex shader
  shader.vertexShader = `uniform float uTime;\n` + shader.vertexShader;

  // Inject wind sway after the built-in position transformation
  shader.vertexShader = shader.vertexShader.replace(
    "#include <begin_vertex>",
    `#include <begin_vertex>
     // ... wind math here ...`
  );

  // Inject SSS before outgoingLight composition in fragment shader
  shader.fragmentShader = shader.fragmentShader.replace(
    "vec3 outgoingLight = reflectedLight.directDiffuse + ...",
    `// SSS injection
     reflectedLight.directDiffuse += ...;
     vec3 outgoingLight = reflectedLight.directDiffuse + ...`
  );
};
```

The injection strings target Three.js r184 shader source. **If Three.js is upgraded beyond r184, these string replacements must be re-validated against the new GLSL source.**

### 9.6 Simple Hinged Animations — No Physics Engine

All mechanical animations are pure `sin(t)` or `lerp()` — no Cannon.js, no Rapier, no Ammo.js:

| Animation | Implementation |
|---|---|
| Pump impeller rotation | `mesh.rotation.z += (pumpRpm / 60) * delta * Math.PI * 2` |
| Water tank fill | `waterMesh.scale.y = lerp(scale.y, targetLevel / tankHeight, 0.012)` |
| Zombie limb swing | `sin(elapsed * 3.2 + zombieId * 1.4) * 0.6` |
| Weapon bob | `sin(bobAccum) * 0.018` per frame |
| Recoil return | `lerp(recoilZ, 0, delta * 12)` |
| Rain drop fall | Manual Y decrement, respawn at top when Y < floor |
| Cloud drift | `mesh.position.x += windSpeed * delta * 0.8` |
| Tree wind sway | GLSL: `sin(instPos.x * 0.8 + uTime * 1.4) * uWind * topFactor` |

### 9.7 Canvas WebGL Configuration

```typescript
<Canvas
  shadows
  camera={{ fov: 75, near: 0.1, far: 550 }}
  gl={{
    antialias: true,
    powerPreference: "low-power",           // requests integrated GPU
    failIfMajorPerformanceCaveat: false,    // never fail on slow GPU
  }}
/>
```

`powerPreference: "low-power"` signals to the browser that integrated graphics is acceptable, preventing the OS from switching to a discrete GPU (which would use more battery on laptops).

### 9.8 Terrain Rendering — No Dynamic LOD

The terrain mesh is static geometry, computed once on mount using `heightAt()` evaluated at each vertex. There is no LOD or chunking system. The trade-off is acceptable because the far-clip is 550 m and the terrain mesh is a single `PlaneGeometry(400, 400, 80, 80)` — 80×80 = 6,400 quads, well within integrated GPU budget.

---

## 10. Procedural Audio Engine

**File:** `src/utils/audioEngine.ts`

### 10.1 Design Principle

Zero external audio files. All sounds are synthesized at runtime using the Web Audio API. The entire engine is a singleton module — no React context, no hooks, no component lifecycle dependency.

### 10.2 Core Primitives

```typescript
function noiseShot(opts: NoiseOpts): void {
  // 1. Create AudioBufferSourceNode with pre-generated white noise
  // 2. Route through BiquadFilterNode (bandpass/lowpass)
  // 3. Route through GainNode with attack/decay envelope
  // 4. Connect to master GainNode → AudioContext.destination
  // 5. Scheduled start/stop
}

function toneBurst(freq, attack, decay, gain, delay): void {
  // OscillatorNode (sine) with exponential frequency sweep down
  // GainNode envelope for percussive transient
}
```

### 10.3 Sound Recipes

| Sound | Technique |
|---|---|
| Pistol | `noiseShot(4200→600Hz bandpass, 0.1s) + noiseShot(280Hz lowpass, 0.16s) + toneBurst(200Hz, 0.1s) + highpass snap` |
| Machine gun | Same but shorter decay (0.07s) and lower peak frequency |
| Bazooka | `noiseShot(1800→200Hz) + noiseShot(80Hz lowpass, 1.1s) + toneBurst(55Hz, 1.4s) + toneBurst(38Hz, 2.0s) + mid crack + debris rattle` |
| Shell casing | `toneBurst(3200Hz ±random) + toneBurst(0.6× freq) + highpass noise` |
| Pistol reload | Three staged `setTimeout()` calls: mag drop (0ms) → mag insert (320ms) → slide rack (620ms) |
| M4 reload | Four stages: 0ms, 220ms, 450ms, 680ms |
| Bazooka reload | Two heavy thunks: 0ms, 700ms |
| Rain | Looping white noise buffer through dual BiquadFilter chain (lowpass 3500Hz + bandpass 5500Hz), gain = `intensity × 0.42` |
| Thunder | `noiseShot(50Hz lowpass, 3.5s) + noiseShot(90Hz, 2.8s) + toneBurst(48Hz, 3.0s) + toneBurst(35Hz, 4.0s)` |

### 10.4 Rain Audio — Frame Tick

```typescript
// RainSystem.tsx useFrame:
useFrame(({ }, delta) => {
  const isStorm = weather.mode === "fluctuating" && isRaining;
  tickAmbience(delta, isRaining, isStorm);
  // ...
});

// audioEngine.ts:
export function tickAmbience(delta, isRaining, isStorm) {
  if (!isRaining) { setRainIntensity(0); return; }
  setRainIntensity(isStorm ? 0.95 : 0.58);
  if (isStorm) {
    _thunderTimer -= delta;
    if (_thunderTimer <= 0) {
      playThunder();
      _thunderTimer = 9 + Math.random() * 20; // 9–29 second intervals
    }
  }
}
```

---

## 11. Environmental Systems — Wheat, Forest, Mountains, Rain

### 11.1 Wheat Field — Technical Detail

**Blade count:** 150,000  
**Geometry:** `PlaneGeometry(0.038, 1.12, 1, 8)` — 8 vertical segments for smooth bend  
**Wind:** Three-octave Gerstner sway + traveling wave front propagating at angle across field  
**SSS:** Fragment shader injection adds warm golden backlit translucency `vec3(1.10, 0.90, 0.48)` based on back-face normal dot product with sun direction  
**Wetness:** `soil.roughness` lerps from 0.94 → 0.22, `metalness` from 0.02 → 0.32 when raining  
**Placement:** Stratified grid jitter — not random — to ensure even coverage with no visible clumping

### 11.2 Forest — Technical Detail

**Cross-plane billboard trick:** Each tree is rendered as three intersecting planes at 0°, 60°, 120°. Three `InstancedMesh` objects share the same `PlaneGeometry(1,1)` and the same `treeMat`, but different rotation quaternions. From any horizontal viewing angle, at least two planes are always facing the viewer, giving a convincing 3D silhouette with zero polygon cost.

**Wind shader:** The top of each billboard (`position.y + 0.5` → 0–1 smoothstep) sways in XZ by `sin(instPos.x * 0.8 + uTime * 1.4) * 0.012 * uWind`. The wind strength `uWind` uniform is driven from `weather.mode`.

### 11.3 Mountains — Technical Detail

**Geological strata texture:** The `makeStrataRockTex()` function paints 12 differently-colored horizontal sedimentary bands with wavy strata edges (simulating real deposition layers), 32 vertical tectonic crack lines, 14 diagonal shear fractures, and 40 weathering highlight patches at the upper (exposed) surfaces. The texture is `RepeatWrapping` with `repeat.set(2, 4)` so it tiles vertically twice as fast as horizontally — matching real rock stratification orientation.

**Snow caps:** Only on peaks where `h > 52`. The snow cone is a smaller `ConeGeometry` placed at `h × 0.44` height, with a snow texture (`makeSnowTex()`) applied. An additional snow drape mesh on the shoulder simulates drift accumulation.

### 11.4 Rain System — Technical Detail

**Drops:** Each `DropData` carries individual `windX`, `windZ` perturbations. A global wind gust timer randomly changes `windGust.x/z` every 2–6 seconds, simulating gusting behavior. Drop speed is 16–26 m/s (realistic heavy rain).

**Wet ground:** A `MeshStandardMaterial` plane at Y=0.025 with `roughness → 0.02` and `metalness → 0.45` when raining. Its UV offset scrolls at `t * 0.012 * vis` to simulate water flowing across the surface. Opacity fades in at 3.5 units/second.

---

## 12. Simulation Data Importer — CSV · JSON · OBJ

**File:** `src/components/SimulationDataPanel.tsx`  
**Context:** `src/context/WeatherContext.tsx` (simStep, simActive)  
**OBJ Context:** `src/context/ImportContext.tsx` + `src/components/OBJViewer.tsx`

### 12.1 CSV Format Expected

The CSV parser uses fuzzy header matching (case-insensitive substring search):

```csv
t_h,irradiance,pv_power,soc,tank_level,pump_rpm,flow_rate,temp,mpc_setpoint,fopid_err,lstm_forecast,wind_speed
0.00,950,11973,87.0,5.03,1450,14.06,32.1,5.00,0.03,9500,3.2
0.25,920,11200,86.5,5.01,1420,13.8,32.5,5.00,0.01,9400,3.4
...
```

Accepted header aliases:
- Time: `t_h`, `time`
- Irradiance: `irradiance`
- PV Power: `pv_power`, `power`
- Battery SoC: `soc`, `battery`
- Tank Level: `tank_level`, `tank`
- Pump RPM: `pump_rpm`, `rpm`
- Flow Rate: `flow_rate`, `flow`
- Temperature: `temp`
- MPC Setpoint: `mpc_setpoint`, `setpoint`
- FOPID Error: `fopid_err`, `error`
- LSTM Forecast: `lstm_forecast`, `lstm`
- Wind Speed: `wind_speed`, `wind`

### 12.2 JSON Format Expected

```json
{
  "meta": {
    "title": "72h Simulation Run — Sudan Farm",
    "source": "MATLAB/Simulink R2024b",
    "duration_h": 72,
    "timestep_min": 15,
    "steps": 288,
    "system": {
      "pv_kW": 12.98,
      "tank_m3": 150,
      "pump_max_m3h": 18.0,
      "battery_kWh": 14.4
    },
    "columns": ["t_h","irradiance","pv_power","soc","tank_level",
                 "pump_rpm","flow_rate","temp","mpc_setpoint",
                 "fopid_err","lstm_forecast","wind_speed"]
  },
  "data": [
    [0.00, 950, 11973, 87.0, 5.03, 1450, 14.06, 32.1, 5.00, 0.03, 9500, 3.2],
    [0.25, 920, 11200, 86.5, 5.01, 1420, 13.80, 32.5, 5.00, 0.01, 9400, 3.4]
  ]
}
```

### 12.3 Playback Engine

```typescript
// SimulationDataPanel.tsx (simplified)
const intervalRef = useRef<number | null>(null);
const stepIdx     = useRef(0);

function startPlayback() {
  const realSecPerStep = (meta.timestep_min * 60) / speed; // seconds per sim step in real time
  intervalRef.current = window.setInterval(() => {
    if (stepIdx.current >= data.length) {
      stopPlayback(); return;
    }
    setSimStep(data[stepIdx.current]); // → WeatherContext → all 3D components update
    setSimActive(true);
    stepIdx.current++;
  }, realSecPerStep * 1000);
}
```

Available speeds: 1× · 5× · 30× · 60× · 120× · 300×  
At 300×, a 15-minute timestep plays in 3 real seconds.

---

## 13. AI-to-AI Handoff Guide

> **ATTENTION FUTURE AI:** This section is written directly for you. Read it completely before touching any file. The project has strong engineering invariants that must not be broken. Violations will cause scientifically incorrect behavior.

### 13.1 How to Orient Yourself in 60 Seconds

1. Open `src/context/WeatherContext.tsx`. This is the single source of truth for all simulation state. Every 3D component reads from `useWeather()`. Nothing bypasses this.

2. Open `src/App.tsx`. All React boolean state lives here. If a UI toggle is broken, it is because a callback chain from `FirstPersonController → App → GameUI` was interrupted. Trace the prop chain.

3. Open `src/utils/audioEngine.ts`. This module is a plain TypeScript singleton. It is not a React component. It does not use hooks. Import its functions directly in any component that needs audio.

4. Open `src/utils/terrain.ts`. The `heightAt(x, z)` function is deterministic and must never be changed without re-testing all terrain-following code (camera, zombie placement, tree placement, wheat field soil).

5. Run `pnpm run typecheck` from `artifacts/3d-game/`. This must pass with zero errors before and after every change you make.

### 13.2 File Editing Rules

**NEVER edit these without understanding the full impact:**

| File | Why it is dangerous |
|---|---|
| `terrain.ts → heightAt()` | Every terrain-following system depends on this being deterministic and consistent. Change it and trees float, zombies sink, the camera stutters. |
| `WeatherContext.tsx → WEATHER_PROFILES` | The three irradiance values (950, 550, 280 W/m²) are physically derived from real Omdurman solar data. Do not change them. |
| `WheatField.tsx → onBeforeCompile` shader injection strings | These target Three.js r184 GLSL. If you upgrade Three.js, re-verify the injection anchor strings exist in the new shader source. |
| `CombatSystem.tsx → MAX_ZOMBIES` | Increasing beyond 50 will exceed the `args[2]` of all 6 `InstancedMesh` declarations, causing a WebGL buffer overflow. |
| `audioEngine.ts → ctx()` function | The AudioContext must be lazily created and resumed. Never create it at module load time — browsers block audio contexts created before a user gesture. |

**ALWAYS safe to modify:**
- Any `WEATHER_PROFILES` visual properties: `skyTop`, `skyMiddle`, `sunColor`
- Any material colors inside any component
- Canvas texture functions in `terrain.ts`
- HUD display formatting in `HUD.tsx`
- The `SimulationDataPanel` layout and sparkline colors

### 13.3 Adding a New 3D Component

1. Create `src/components/YourComponent.tsx`
2. Import and place it inside `Scene.tsx` (the R3F scene assembler)
3. If it needs simulation data, call `const { weather, simStep } = useWeather()` at the top
4. If it needs audio, import named functions from `../utils/audioEngine`
5. If it has clickable behavior, call `setSelected({ type, title, lines })` from `useWeather()` on click
6. Run `pnpm run typecheck` — fix all errors before proceeding

### 13.4 Adding a New Keybinding

1. Open `FirstPersonController.tsx`, find the `onKey` handler
2. Add your case: `if (e.code === "KeyX") onYourCallback();`
3. Add `onYourCallback: () => void` to the `FirstPersonController` props interface
4. In `App.tsx → AppInner`, add a `const handleYourCallback = useCallback(() => ..., [])` state setter
5. Pass it as `onYourCallback={handleYourCallback}` to `<FirstPersonController />`
6. Add the key to `StartScreen.tsx` in the `<Key label="X" desc="..." />` list

### 13.5 Connecting to a Live API

If the future system needs to pull live sensor data from an actual SCADA server rather than an imported CSV:

1. Create `src/hooks/useLiveSCADA.ts`
2. Implement a `setInterval`-based fetch loop:
```typescript
export function useLiveSCADA(url: string, intervalMs = 5000) {
  const { setSimStep, setSimActive } = useWeather();
  useEffect(() => {
    const id = setInterval(async () => {
      const res  = await fetch(url);
      const data = await res.json();
      setSimStep({
        t:          data.timestamp_h,
        irr:        data.irradiance_wm2,
        pv:         data.pv_power_w,
        soc:        data.battery_soc_pct,
        tank_level: data.tank_level_m,
        pump_rpm:   data.pump_rpm,
        flow:       data.flow_m3h,
        temp:       data.temp_c,
        mpc_sp:     data.mpc_setpoint,
        fopid_err:  data.fopid_error,
        lstm:       data.lstm_forecast_wm2,
        wind:       data.wind_speed_ms,
      });
      setSimActive(true);
    }, intervalMs);
    return () => clearInterval(id);
  }, [url]);
}
```
3. Call `useLiveSCADA("https://your-api/scada")` inside `AppInner`
4. The entire 3D scene will respond to live data automatically because it all reads from `useWeather()`

---

## 14. Engineering Constraints — Non-Negotiable Laws

These constraints reflect the real engineering design of the physical system in Omdurman. Violating them produces a scientifically incorrect simulation.

### 14.1 The Multi-Modal Storage Strategy

The system has **two storage reservoirs**, not one:

1. **Water tank** — stores harvested solar energy in the form of pumped water (gravitational potential energy). 150 m³ capacity. Level driven by `pumpRpm` and `flowRate`.
2. **Soil moisture** — stores plant-available water in the root zone. Modeled as a 0–1 saturation fraction per field row.

**Why this matters:** The MPC controller's optimization objective spans both reservoirs simultaneously. It must decide: pump now to fill the tank (costs battery SoC), or delay pumping and accept lower soil moisture (stresses the crop). Collapsing these two into a single "water stored" variable loses this trade-off and makes the MPC trivially solvable in a way that does not reflect reality.

**In code:** `weather.waterLevelTarget` drives the tank. The `IrrigationField.tsx` soil moisture bands are driven separately by `weather.flowRate`. These are always two independent variables.

### 14.2 The Kasten-Czeplak Model for Clear-Sky Irradiance

The physical irradiance values in the three weather profiles are not arbitrary. They are derived from the Kasten-Czeplak empirical model for Omdurman:

```
G_cs = G_sc × (a₀ + a₁ × e^(−k / cos(SZA)))
```

Where:
- `G_sc = 1361 W/m²` (solar constant)
- `a₀ = 0.4237 − 0.00821 × (6 − altitude_km)²`
- `a₁ = 0.5055 + 0.00595 × (6.5 − altitude_km)²`
- `k = 0.2711 + 0.01858 × (2.5 − water_vapor_cm)²`
- `altitude_km ≈ 0.38` for Omdurman
- `SZA = Solar Zenith Angle` at solar noon for Omdurman latitude (15.6°N)

At solar noon on a clear summer day in Omdurman, this yields approximately 950 W/m², which is the `clear` profile value. The `fluctuating` and `overcast` profiles use 58% and 29% of this peak respectively, matching real measured data from Sudan's National Meteorological Authority.

**Future AI:** If you add a new weather profile or adjust irradiance values, use the Kasten-Czeplak formula above. Do not invent numbers.

### 14.3 The Solar Zenith Angle as a Physical Gate

The Solar Zenith Angle (SZA) determines whether the sun is above the horizon and thus whether the PV system can produce power. In this project's control architecture, SZA functions as a **binary physical gate** in the supervisory logic:

```
IF SZA > 90°  (sun below horizon):
    → Force pumpRpm = 0
    → Force PV power = 0
    → Battery-only mode: discharge only for night irrigation if SoC permits
    → MPC operates in "night mode": no irradiance forecast needed

IF SZA ≤ 90°  (sun above horizon):
    → Enable MPPT tracking
    → Enable MPC irradiance forecasting
    → Enable pump operation based on available power and tank level
```

**The SZA is NOT an input to the Physics-Guided LSTM.** The LSTM forecasts irradiance (`G_cs`) given time-of-day and atmospheric conditions. SZA is the constraint that tells the system supervisor whether to even ask the LSTM for a forecast. This distinction matters because:

- A neural network trained with SZA as an input would learn a spurious correlation (SZA → irradiance) that collapses the model into a simple geometric calculator
- The LSTM's value is in learning the **residual** between the Kasten-Czeplak prediction and the actual measured irradiance — i.e., it learns cloud cover, aerosol loading, and humidity effects
- SZA must remain outside the neural network and inside the physical gating logic

**In code:** If you add a `useSolarPosition()` hook that computes real SZA from latitude/longitude and time, feed it to the MPC setpoint logic and lighting — but do not include it as a feature in any LSTM dataset export.

---

## 15. Extending the System — Exact Instructions for Future AI

### 15.1 Importing MATLAB Simulink Data — Step-by-Step

**Step 1: Export from MATLAB**

In your MATLAB script, export the simulation workspace to CSV:
```matlab
% MATLAB script: export_sim.m
simOut = sim('SolarIrrigationModel', 'SimulationMode', 'normal');

t_h         = simOut.tout / 3600;
irradiance  = simOut.logsout{1}.Values.Data;
pv_power    = simOut.logsout{2}.Values.Data;
soc         = simOut.logsout{3}.Values.Data;
tank_level  = simOut.logsout{4}.Values.Data;
pump_rpm    = simOut.logsout{5}.Values.Data;
flow_rate   = simOut.logsout{6}.Values.Data;
temp        = simOut.logsout{7}.Values.Data;
mpc_setpoint= simOut.logsout{8}.Values.Data;
fopid_err   = simOut.logsout{9}.Values.Data;
lstm_forecast= simOut.logsout{10}.Values.Data;
wind_speed  = simOut.logsout{11}.Values.Data;

T = table(t_h, irradiance, pv_power, soc, tank_level, pump_rpm, ...
          flow_rate, temp, mpc_setpoint, fopid_err, lstm_forecast, wind_speed);
writetable(T, 'simulation_72h.csv');
disp('Exported: simulation_72h.csv');
```

**Step 2: Export from Python (scipy/pandas)**

```python
# python: export_sim.py
import pandas as pd
import numpy as np

# Load your simulation results
t_hours = np.arange(0, 72, 0.25)   # 15-min timesteps, 72 hours

df = pd.DataFrame({
    't_h':           t_hours,
    'irradiance':    irradiance_array,   # W/m²
    'pv_power':      pv_power_array,     # W
    'soc':           soc_array,          # %
    'tank_level':    tank_level_array,   # m (0–6)
    'pump_rpm':      pump_rpm_array,     # RPM
    'flow_rate':     flow_rate_array,    # m³/h
    'temp':          temp_array,         # °C
    'mpc_setpoint':  mpc_sp_array,       # m (tank target)
    'fopid_err':     fopid_err_array,    # m (error from setpoint)
    'lstm_forecast': lstm_array,         # W/m² (irradiance forecast)
    'wind_speed':    wind_array,         # m/s
})
df.to_csv('simulation_72h.csv', index=False)
print(f"Exported {len(df)} rows to simulation_72h.csv")
```

**Step 3: Load into the 3D World**

1. Open the simulation at `http://localhost/` (or your deployed URL)
2. Click to start the game (acquire lock)
3. The `SimulationDataPanel` is always visible in the bottom-right of the screen while in-game
4. Click "Import CSV/JSON" and select `simulation_72h.csv`
5. The panel will show: file name, row count, column list, sparklines for irradiance and tank level
6. Set playback speed (1× for real-time, 300× for fast forward through 72 hours in ~14 minutes)
7. Click "▶ Play" — the 3D world immediately responds:
   - Tank level mesh rises/falls
   - Pump impeller spins faster/slower
   - Sky color changes with irradiance
   - HUD numbers update every tick
   - Battery SoC badge color shifts

### 15.2 Adding Pump RPM → Impeller Animation (if not already connected)

If `PumpSystem.tsx` is not yet reading `weather.pumpRpm`, add this to its `useFrame`:

```typescript
// PumpSystem.tsx
import { useWeather } from "../context/WeatherContext";

export default function PumpSystem({ position }: { position: [number, number, number] }) {
  const { weather } = useWeather();
  const impellerRef = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (impellerRef.current && weather.pumpRpm) {
      // Convert RPM to rad/s: (rpm / 60) * 2π
      const radsPerSec = (weather.pumpRpm / 60) * Math.PI * 2;
      impellerRef.current.rotation.z += radsPerSec * delta;
    }
  });

  return (
    <group position={position}>
      {/* ... pump body meshes ... */}
      <mesh ref={impellerRef}>
        <cylinderGeometry args={[0.18, 0.18, 0.04, 12]} />
        <meshStandardMaterial color="#2244AA" metalness={0.8} roughness={0.3} />
      </mesh>
    </group>
  );
}
```

### 15.3 Adding a New Simulation Column — e.g., Soil Moisture

If your MATLAB export adds a `soil_moisture` column (0.0–1.0):

1. **Add to `SimStep` interface in `WeatherContext.tsx`:**
```typescript
export interface SimStep {
  // ... existing fields ...
  soil_moisture?: number;  // 0–1 saturation fraction
}
```

2. **Add to CSV parser in `SimulationDataPanel.tsx`:**
```typescript
result.push({
  // ... existing fields ...
  soil_moisture: get("soil_moisture") || get("theta"),
});
```

3. **Add to WeatherData if needed for display:**
```typescript
// In WeatherContext.tsx weather composition:
soilMoisture: simStep.soil_moisture ?? 0.65,
```

4. **Consume in `IrrigationField.tsx`:**
```typescript
const { weather } = useWeather();
// Use weather.soilMoisture to tint soil color from brown (0.0) to dark (1.0)
const soilColor = new THREE.Color().setHSL(0.08, 0.45, 0.22 - weather.soilMoisture * 0.12);
```

### 15.4 Adding Real-Time SZA Computation

```typescript
// src/utils/solarPosition.ts

/**
 * Compute Solar Zenith Angle for Omdurman, Sudan
 * lat = 15.6°N, lon = 32.5°E
 */
export function computeSZA(utcDate: Date): number {
  const lat = 15.6 * Math.PI / 180;  // radians
  const dayOfYear = getDayOfYear(utcDate);
  const decl = -23.45 * Math.cos((360 / 365) * (dayOfYear + 10) * Math.PI / 180) * Math.PI / 180;
  const hourAngle = (utcDate.getHours() + 32.5 / 15 - 12) * 15 * Math.PI / 180;
  const cosSZA = Math.sin(lat) * Math.sin(decl)
               + Math.cos(lat) * Math.cos(decl) * Math.cos(hourAngle);
  return Math.acos(Math.max(-1, Math.min(1, cosSZA))) * 180 / Math.PI;
}

function getDayOfYear(d: Date): number {
  return Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 0).getTime()) / 86400000);
}

/**
 * Physical gate: returns true only when sun is above horizon
 * SZA < 90° means daylight, SZA ≥ 90° means night
 */
export function isPVEnabled(utcDate: Date): boolean {
  return computeSZA(utcDate) < 90;
}
```

Use `isPVEnabled()` in any supervisory control logic. Never pass the SZA value itself into a neural network feature vector.

### 15.5 Checklist Before Every Commit

```
□ pnpm run typecheck  →  zero errors
□ The three weather profiles still use irradiance 950/550/280 W/m²
□ SZA is NOT passed to any LSTM/neural network inference function
□ water tank level and soil moisture remain two separate state variables
□ No new PointLight or SpotLight with shadow casting added
□ All new textures use useMemo() to prevent re-generation every frame
□ All new InstancedMesh counts are hardcoded in args[2] with sufficient headroom
□ audioEngine functions wrapped in try/catch (browsers may block on first load)
□ heightAt() not modified
```

---

*End of documentation. Version: Round 6 complete. Last updated: May 2026.*  
*Built entirely by Replit AI. All textures, sounds, shaders, and physics are procedurally generated — no external assets.*
