# Solar SCADA World — Setup & Installation

## Quick Start (بدون انترنت)

### Step 1: Extract
```bash
unzip solar_scada_world_complete.zip
cd artifacts/3d-game
```

### Step 2: Install Dependencies
```bash
npm install
# أو
pnpm install
```

### Step 3: Run Development Server
```bash
npm run dev
# أو
pnpm dev
```

### Step 4: Open Browser
انتظر حتى تري الرسالة:
```
  ➜  Local:   http://localhost:5173/
```

ثم افتح المتصفح على: **http://localhost:5173**

---

## Game Controls

| Key | Action |
|-----|--------|
| **Click / Enter** | دخول العالم |
| **W A S D** | الحركة |
| **Mouse** | النظر حول المشهد |
| **Shift** | الجري السريع |
| **Space** | القفز |
| **E** | فحص الأجهزة |
| **Click** | إطلاق النار |
| **Scroll / Tab** | تبديل السلاح |
| **R** | إعادة التحميل |
| **5** | توليد الزومبيز |
| **1/2/3** | تغيير الطقس |
| **6** | تشغيل/إيقاف المطر |
| **V** | إظهار/إخفاء السلاح |
| **H** | إظهار/إخفاء لوحة المعلومات |
| **0** | إخفاء واجهة القتال |
| **9** | وضع سينمائي |

---

## What's Included

✅ كامل المشروع 3D  
✅ نظام الطقس الديناميكي  
✅ نظام القتال والزومبيز  
✅ محرك صوت مدمج (Web Audio API)  
✅ نظام واردات البيانات (CSV/JSON)  
✅ جميع الملافات التي تم تطويرها  

---

## Files Structure

```
artifacts/3d-game/
├── src/
│   ├── App.tsx                    # Root component
│   ├── components/                # All 3D & UI components
│   ├── context/                   # Weather & Import state
│   └── utils/                     # terrain.ts, audioEngine.ts
├── package.json
├── vite.config.ts
├── tsconfig.json
└── index.html
```

---

## Requirements

- **Node.js**: 18+ or 20+
- **Browser**: Chrome/Firefox/Safari (WebGL support)
- **Internet**: بدون انترنت بعد التثبيت الأولي

---

## Troubleshooting

### المتصفح لا يعرض المشهد 3D
- تأكد من دعم WebGL: https://www.khronos.org/webgl/wiki/Getting_Started/Detecting_WebGL
- جرب متصفح آخر (Chrome أفضل)
- تأكد من الرسومات متفعلة

### الصوت لا يعمل
- بعض المتصفحات تتطلب تفاعل المستخدم قبل تشغيل الصوت
- اضغط على أي شيء في الصفحة أولاً

### البطء / التأخير
- هذا طبيعي على الأجهزة الضعيفة
- قلل جودة المتصفح أو الدقة

---

## Documentation

للتفاصيل الكاملة، راجع: `SOLAR_SCADA_DOCS.md`

---

**Built with React Three Fiber • Three.js • TypeScript**  
**Smart Solar Irrigation System • Omdurman, Sudan**
